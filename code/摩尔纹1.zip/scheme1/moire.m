%生成0/1数据集

in_pth = './in';


d = dir(in_pth);
for i = 1:length(d)
    
    if d(i).isdir == 1 
        continue
    end

    img = imread([in_pth,'/',d(i).name]);
    img = imresize(img,[64 64]);
    out1 = moire_embed(img,1);
    imwrite(out1,['./1/',d(i).name]);
    out0 = moire_embed(img,0);
   imwrite(out0,['./0/',d(i).name]);
%    width = floor(col / 8);
%    height = floor(row / 8);

%    for j = 0: 7
%       for k = 0:7
%            r = j * height + 1;
%            c = k * width + 1;
%            name = strsplit(d(i).name,'.');
%
%            block = img(r:r + height - 1,c:c+ width - 1,:);
%            imwrite(moire_embed(block,1),['./1/',char(name(1)),'_',char(string(j)),'_',char(string(k)),'.',char(name(2))]);
%            
%            block = img(r:r + height - 1,c:c+ width - 1,:);
%            imwrite(moire_embed(block,0),['./0/',char(name(1)),'_',char(string(j)),'_',char(string(k)),'.',char(name(2))]);

%       end
%    end
end
