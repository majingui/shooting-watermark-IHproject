% 往一个像素矩阵（3颜色通道）嵌入0/1类型的摩尔纹
% 函数名moire_embed
% 输入：
% imat          图片
% info          嵌入信息
% 输出：
% mat           带有摩尔纹的像素矩阵
% 示例：
% mat = moire_embed(imat,0);
% mat = moire_embed(imat,1);
%

function mat = moire_embed(imat,info)
    imat = double(imat);                    % uint8 -> double
    Image = imat;
    [row, col, ~] = size(Image);            % 获取矩阵大小
    
    mat = Image;                              
    Degree = 10;                             % 强度为1
    
    m_x = floor(col / 2);
    m_y = floor(row / 2);
    switch(info)
        case 0
            Center_X = 1;
            Center_Y = 1;
        case 1
            Center_X = m_x;
            Center_Y = 1;
        case 2
            Center_X = col;
            Center_Y = 1;
        case 3
            Center_X = 1;
            Center_Y = m_y;
        case 4
            Center_X = col;
            Center_Y = m_y;
        case 5
            Center_X = 1;
            Center_Y = row;
        case 6
            Center_X = m_x;
            Center_Y = row;
        case 7
            Center_X = col;
            Center_Y = row;
        otherwise
            disp("not suport info value ",info);
    end

    

    for i = 1 : row
        for j = 1 : col
            % 对每一像素点进行处理
            x0 = j - Center_X;
            y0 = i - Center_Y;
            if(x0 ~= 0)
                beta = atan(y0 / x0);       % 计算像素点到中心点的弧度
                if(x0 < 0)
                    beta = beta + pi;
                end
            else                            % y/x = 无穷大
                beta = pi / 2;
            end
            radius = sqrt(x0 * x0 + y0 * y0);% 计算像素点到中心点的长度
            beta = beta + radius * Degree;   % 获取新的弧度（旋转）
            % 取得(旋转后的)新点坐标
            x1 = radius * sin(beta);          
            y1 = radius * cos(beta);

            x = floor(x1) + Center_X;
            y = floor(y1) + Center_Y;
            % 如果新点在图片上，则使用该坐标处的像素值取代原来的
            if(x > 0 && x <= col && y <= row && y > 0)
                mat(i,j) = Image(y,x);
            end
        end
    end
    mat = uint8(mat);                         % double -> uint8
end