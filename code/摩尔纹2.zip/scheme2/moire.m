%生成0/1数据集
clear
in_pth = './in';

% 删除原数据
if exist("input","dir") ~= 0 
    rmdir("input","s");
end
% 新建数据文件夹
mkdir("input/train");
mkdir("input/test");
for i = 0 : 7
    mkdir(['input/train/',char(string(i))]);
    mkdir(['input/test/',char(string(i))]);
end

d = dir(in_pth);
cnt = 0;
trainCnt = floor(length(d) * 0.8);
for i = 1:length(d)
    
    if d(i).isdir == 1 
        continue
    end
    
    img = imread([in_pth,'/',d(i).name]);
    dir = 'input/';
    if i < trainCnt 
        dir = [dir,'train/'];
    else
        dir = [dir,'test/'];
    end

    parfor info = 0:7
       out = moire_embed(img,info);
       imwrite(out,[dir,char(string(info)),'/',char(string(info)),'_',char(string(cnt)),'.jpg']);
    end

   cnt = cnt + 1;
end
