import re
def correct(hanmingma):
    # 读入
    '''
    f = open('input.txt', 'r')
    d = f.read()
    f.close()
    '''
    data_list = hanmingma
    d = re.sub("[^0-9]", "", data_list)
    #print("in:")
    #print("input"+d)

    data = list(d)
    data.reverse()
    c, ch, j, r, error, h, parity_list, h_copy = 0, 0, 0, 0, 0, [], [], []

    for k in range(0, len(data)):
        p = (2 ** c)
        h.append(int(data[k]))
        h_copy.append(data[k])
        if (p == (k + 1)):
            c = c + 1

    for parity in range(0, (len(h))):
        ph = (2 ** ch)
        if (ph == (parity + 1)):

            startIndex = ph - 1
            i = startIndex
            toXor = []

            while (i < len(h)):
                block = h[i:i + ph]
                toXor.extend(block)
                i += 2 * ph

            for z in range(1, len(toXor)):
                h[startIndex] = h[startIndex] ^ toXor[z]
            parity_list.append(h[parity])
            ch += 1
    parity_list.reverse()
    error = sum(int(parity_list) * (2 ** i) for i, parity_list in enumerate(parity_list[::-1]))

    if ((error) == 0):
        print('There is no error in the hamming code received')
        check = data_list[:]
        flag = 0

    elif ((error) > len(h_copy)):#error是下标加1，不能等于
        print('Error cannot be detected')
        flag = 0

    else:
        print('Error is in', error, 'bit')

        if (h_copy[error - 1] == '0'):
            h_copy[error - 1] = '1'

        elif (h_copy[error - 1] == '1'):
            h_copy[error - 1] = '0'
            print('After correction hamming code is:- ')
        h_copy.reverse()
        check = str(int(''.join(map(str, h_copy))))
        # print(check)
        flag = 1

    # 保存
    '''
    fh = open('output.txt', 'w', encoding='utf-8')
    if flag:
        fh.write(check)
    else:
        fh.write(d)
    fh.close()
    '''
    #发现问题了因为前面check有问题，前面的0忽略了，下面补起来，然后是用check不是用d，d是原来的
    for i in range(len(h_copy)-len(check)):
        check = '0'+check
    #现在是正确的check了
    #print(check)
    # 去掉纠错码，提取信息
    position = 1
    msg = ""
    for i in range(len(check)):
        j = len(check) - i - 1
        if i == position - 1:
            position = position * 2
            continue
        msg = msg + check[j]
    # msg是倒过来的
    # print(msg)

    #print("out:")
    #print('[', end="")
    originmsg = []
    for i in range(len(msg)):
        #print(msg[len(msg) - i - 1], end="")
        originmsg.append(msg[len(msg)-i-1])
        if i != len(msg) - 1:
            p = 0
            #print(',', end="")
    #print(']')
    return originmsg
#注意输入str输出list
hanming = "011000101100" #正确的msg+汉明
hanming = "001000101100" #修改一位
hanming = "0110011" #修改一位
hanming = "0110011" #修改一位
msg = correct(hanming)
print(msg) #"01100101"


#注意输入str输出list