import numpy as np
import torchvision

from skimage import io
from skimage import transform
import matplotlib.pyplot as plt
import os
import torch
from torch.utils.data import Dataset,DataLoader
from torchvision.transforms import transforms
from model import *

class MyDataset(Dataset):
    def __init__(self, root_dir, names_file, transform=None):
        self.root_dir = root_dir  # 根目录
        self.names_file = names_file  # .txt文件路径
        self.transform = transform  # 数据预处理
        self.size = 0  # 数据集大小
        self.names_list = []  # 数据集路径列表

        if not os.path.isfile(self.names_file):
            print(self.names_file + 'does not exist!')
        file = open(self.names_file)
        for f in file:  # 循环读取.txt文件总每行数据信息
            self.names_list.append(f)
            self.size += 1

    def __len__(self):
        return self.size

    def __getitem__(self, index):
        #image_path = self.root_dir + self.names_list[index].split(' ')[0]  # 获取图片数据路径
        image_path = self.names_list[index].split(' ')[0]
        if not os.path.isfile(image_path):
            print(image_path + 'does not exist!')
            return None
        image = io.imread(image_path)  # 读取图片
        label = int(self.names_list[index].split(' ')[1])  # 读取标签

        return image, label
        # 下面需要封装数据增强
        # sample = {'image':image,'label':lable}
        # if self.transform:
        #    sample = self.transform(sample)

        # return sample #返回图片及对应的标签

train_data = MyDataset(root_dir='./data/train',names_file='./data/train/train.txt',transform=torchvision.transforms.ToTensor()) #torchvision.transforms.ToTensor()
train_dataloader = DataLoader(dataset=train_data,batch_size=16,shuffle=True)
test_data = MyDataset(root_dir='./data/val',names_file='./data/val/val.txt',transform=torchvision.transforms.ToTensor()) #transform.toTensor()#可以试试这个
test_dataloader = DataLoader(dataset=test_data,batch_size=16,shuffle=True) #

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

train_data_size = len(train_data)
test_data_size = len(test_data)

print("训练数据集长度：{}".format(train_data_size))
print("测试数据集长度：{}".format(test_data_size))

#创建网络模型

# 从头开始训练
#myNET = myNET()#


myNET = torch.load('./modelsave/molnet1.pth')#注意加载的model

#损失函数
myNET = myNET.to(device)
loss_fn = nn.CrossEntropyLoss()
loss_fn = loss_fn.to(device)
#优化器
#Learning_rate=0.01
#1e-2=1x10^(-2)=1/100=0.01
#learning_rate = 1e-4#1e-5训练很慢，20轮还是50%
learning_rate = 1e-5
#learning_rate = 1e-6#用于后期训练
optimizer = torch.optim.SGD(myNET.parameters(),lr=learning_rate)

#设置训练网络的一些参数
#记录训练的次数
total_train_step = 0
#记录测试的次数
total_test_step = 0
#训练的轮数
epoch = 100#一百论一百轮来训练，改变学习率
greatacc = 0
#添加tensorboard
#writer = SummaryWriter("../logs_train")

for i in range(epoch):
    print("-------第{}轮开始训练-------".format(i+1))
#训练步骤开始
    for data in train_dataloader:
        #print("aa")
        imgs, targets = data
        imgs = imgs.permute(0,3,1,2)
        imgs = imgs.float()
        #print("bb")
        imgs = imgs.to(device)
        #print("cc")
        targets = targets.to(device)
        outputs = myNET(imgs)
        loss = loss_fn(outputs,targets)

        #优化器优化模型
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    total_train_step = total_train_step + 1
    if total_train_step % 100 == 0:
        print("训练次数：{}，loss：{}".format(total_train_step,loss.item()))
        #writer.add_scalar("train_loss",loss.item(),total_train_step)

#测试步骤开始
    myNET.eval()
    total_test_loss = 0
    total_accuracy = 0
    with torch.no_grad():
        for data in test_dataloader:
            imgs, targets = data
            imgs = imgs.permute(0, 3, 1, 2)
            imgs = imgs.float()
            imgs = imgs.to(device)
            targets = targets.to(device)
            outputs = myNET(imgs)
            loss = loss_fn(outputs,targets)
            total_test_loss = total_test_loss + loss.item()
            accuracy =(outputs.argmax(1) == targets).sum()
            total_accuracy = total_accuracy + accuracy

    print("整体测试集上的Loss：{}".format(total_test_loss))
    print("整体测试集的正确率：{}".format(total_accuracy/test_data_size))
    '''writer.add_scalar("test_loss",total_test_loss,total_test_step)
    writer.add_scalar("test_accuracy",total_accuracy/test_data_size,total_test_step)'''
    total_test_step = total_test_step + 1
    if(greatacc < total_accuracy/test_data_size):
        greatacc = total_accuracy/test_data_size
        torch.save(myNET, "./modelsave/molnet2-alldata-200epoch-finetune.pth")
        print("已更新最优模型")
    #torch.save(myNET,"./modelsave/myNET_{}.pth".format(i))
    #print("模型已保存")

#writer.close()
