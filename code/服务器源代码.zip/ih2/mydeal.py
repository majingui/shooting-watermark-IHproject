#!/usr/bin/python
# -*- coding:utf8 -*-
#这个脚本用于将大量文件进行重命名
import os
import random

names = ['.jpg']  # 需要随机替换的后缀名列表


def test(path):
    files = os.listdir(path)  # 获取当前目录的所有文件及文件夹
    i = 0
    for file in files:
        try:
            file_path = os.path.join(path, file)  # 获取绝对路径
            if os.path.isdir(file_path):  # 判断是否是文件夹
                test(file_path)  # 如果是文件夹，就递归调用自己
            else:
                print(file_path)
                extension_name = os.path.splitext(file_path)  # 将文件的绝对路径中的后缀名分离出来
                print(extension_name)
                os.rename(file_path, "./data/val/1/"+str("1_")+str(i)+".jpg")  # 对文件进行重命名
            i = i + 1
        except:
            continue  # 可能会报错，所以用了try-except,如果要求比较严格，不需要报错，就删除异常处理，自己调试


test(r'./data/val/1/')
