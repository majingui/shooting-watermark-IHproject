#这个文件用于生成标签txt文件
targetfilepath = "./data/train/train.txt"
with open(targetfilepath, mode='w') as f:
    for i in range(894):
        f.write("./data/train/0/"+"0_"+str(i)+".jpg 0\n")
    for i in range(894):
        f.write("./data/train/1/"+"1_"+str(i)+".jpg 1\n")

targetfilepath = "./data/test/test.txt"
with open(targetfilepath, mode='w') as f:
    for i in range(150):
        f.write("./data/test/0/"+"0_"+str(i)+".jpg 0\n")
    for i in range(150):
        f.write("./data/test/1/"+"1_"+str(i)+".jpg 1\n")

targetfilepath = "./data/val/val.txt"
with open(targetfilepath, mode='w') as f:
    for i in range(150):
        f.write("./data/val/0/"+"0_"+str(i)+".jpg 0\n")
    for i in range(150):
        f.write("./data/val/1/"+"1_"+str(i)+".jpg 1\n")
