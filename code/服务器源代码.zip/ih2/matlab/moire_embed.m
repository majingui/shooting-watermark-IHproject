% 往一个像素矩阵（3颜色通道）嵌入0/1类型的摩尔纹
% 函数名moire_embed
% 输入：
% imat          图片
% embed_type    嵌入类型0/1
% 输出：
% mat           带有摩尔纹的像素矩阵
% 示例：
% mat = moire_embed(imat,0);
% mat = moire_embed(imat,1);
%

function mat = moire_embed(imat,embed_type)
    imat = double(imat);                    % uint8 -> double
    Image = imat;
    [row, col,~] = size(Image);             % 获取矩阵大小
    mat = Image;                              
    Degree = 1;                             % 强度为1

    % 设置坐标原（中心）点
    if (embed_type ~= 0)                    % 类型1 矩阵左上角               
        Center_X = 1;
        Center_Y = 1;
    else                                    % 类型2 矩阵右下角
        Center_X = col;
        Center_Y = row;
    end

    for i = 1 : row
        for j = 1 : col
            % 对每一像素点进行处理
            x0 = j - Center_X;
            y0 = i - Center_Y;
            if(x0 ~= 0)
                beta = atan(y0 / x0);       % 计算像素点到中心点的弧度
                if(x0 < 0)
                    beta = beta + pi;
                end
            else                            % y/x = 无穷大
                beta = pi / 2;
            end
            radius = sqrt(x0 * x0 + y0 * y0);% 计算像素点到中心点的长度
            beta = beta + radius * Degree;   % 获取新的弧度（旋转）
            % 取得(旋转后的)新点坐标
            x = radius * sin(beta);          
            y = radius * cos(beta);

            % 如果新点在图片上，则使用该坐标处的像素值取代原来的
            % 想让图片尽可能看起来不突兀，p、q的取值比较随意
            if(x>1 && x<col && y<row && y>1)
                x1 = floor(x);
                y1 = floor(y);
                p = x-x1;
                q = y-y1;
                mat(i,j) = (1-p)*(1-q)*Image(y1,x1)+p*(1-q)*Image(y1,x1+1) + q*(1-p)*Image(y1+1,x1)+p*q*Image(y1+1,x1+1);
                %mat(i,j,1) = mat(y1,x1,1);
                %mat(i,j,2) = mat(y1,x1,2);
                %mat(i,j,3) = mat(y1,x1,3);
            end
        end
    end
    mat = uint8(mat);                         % double -> uint8
end