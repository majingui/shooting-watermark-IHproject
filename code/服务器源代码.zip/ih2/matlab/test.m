msg = hide('../inputimg/cat.jpg','../outputimg/catcover.jpg');
%disp(msg);