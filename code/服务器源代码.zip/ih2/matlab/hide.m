function [msg] = hide(filename,savepath);
%读图
rgb=imread(filename);
[m,n,c]=size(rgb);
%读信息
frr=fopen('msg.txt', 'r');
%原始秘密信息
msg = [0,1,1,0,0,1,1];
%补全整个字节
for i = 1:(8 - length(msg))
    msg = [msg,-1];
end
%[msg,total]=fread(frr, 'ubit1');
%msg =[0,1,1,0,0,1,0,1,0,1,1,0,0,1,0,1,0,1,1,0,0,1,0,1,0,1,1,0,0,1,0,1,0,1,1,0,0,1,0,1,0,1,1,0,0,1,0,1,0,1,1,0,0,1,0,1,0,1,1,0,0,1,0,1];%给lena和bell的
%msg = [0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1];%给cat的
%msg = [0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1];
%msg = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
%msg = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1];

fclose(frr);
%下面根据秘密信息生成摩尔纹
M = floor(m / 64);
N = floor(n / 64);
total = 64;%注意！！！！！！！
count=1;
%将秘密信息冗余化
msg = [0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1];
for i = 1:M
    for j = 1:N
        block = rgb((i-1)*64+1:(i)*64,(j-1)*64+1:(j)*64,:);
        block1 = ones([64,64,3]).*0.2 %构造特殊图
        if(count <= total)
            if (msg(count)~=-1)
            block = moire_embed(block, msg(count));
            end
            %test
            [mm,nn,tt] = size(block);
            if(msg(count)==1)
                block1 = block1.*2;
            end
            %block = ones([mm,nn,tt]);
        end
        if(j == 1)
            A = block;
            A1 = block1;
        else
            A = [A, block];
            A1 = [A1,block1]
        end
        %subplot(M,N,count);
        %imshow(block);
        count = count+1;
    end
    %把拼好的列再拼成图
    if(i==1)
        B = A;
        B1 = A1;
    else
        B = [B; A];
        B1 = [B1;A1];
    end
end
% %分行列
% M=8;N=8;
% %做个对齐操作
% xb=round(m/M)*M;yb=round(n/N)*N;
% rgb=imresize(rgb,[xb,yb]);
% [m,n,c]=size(rgb);
% count =1;
% for i=1:M
%     for j=1:N
%         %分块
%         block = rgb((i-1)*m/M+1:m/M*i,(j-1)*n/N+1:j*n/N,:);
%         %这里用来操作每个块
%         %还有bit流就正常嵌入，没有就不管
%         if(count <= total)
%             block = moire_embed(block, msg(count));
%         end
%         %拼每一列
%         if(j == 1)
%             A = block;
%         else
%             A = [A, block];
%         end
%         %subplot(M,N,count);
%         %imshow(block);
%         count = count+1;
%     end
%     %把拼好的列再拼成图
%     if(i==1)
%         B = A;
%     else
%         B = [B; A];
%     end
% 
% end

%imshow(B);
%imshow(B1);
imwrite(B,savepath);
%imwrite(B1,"../outputimg/test.jpg");
return ;
end

