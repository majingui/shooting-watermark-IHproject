import torch
import torchvision
# 数据增强技术
from PIL import Image
img = Image.open("/root/ih2/jiaozhengtestimg/catjiaozheng.jpg")
trans = torchvision.transforms.Resize([512,512])
img = trans(img)
img.save("/root/ih2/jiaozhengtestimg/catjiaozhengchange.jpg")