import torch
import torchvision.transforms

a = torch.tensor(5)
print(5)
print(a.item())
#下面用于把图片进行大小放缩
from PIL import Image
img = Image.open("/root/ih2/inputimg/cat.jpg")
trans = torchvision.transforms.Resize([512,512])
img = trans(img)
img.save("/root/ih2/outputimg/cat.jpg")