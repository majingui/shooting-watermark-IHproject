import numpy as np
import torchvision
#



#这份代码用于把灰度图变成三维度图
from skimage import io
from skimage import transform
import matplotlib.pyplot as plt
import os
import torch
from torch.utils.data import Dataset,DataLoader
from torchvision.transforms import transforms
from model import *
path = "./data/test/0/"
for i in range(150):#注意这里
    img = io.imread(path+"0_"+str(i)+".jpg")
    #img = torch.Tensor(img)
    #print(img.shape)
    shape = img.shape
    try:
        if shape[2]!=3:
            print(path+"0_"+str(i)+".jpg")
    except:
        print(path + "0_" + str(i) + ".jpg")
        tmpimg = np.zeros((64,64,3),dtype='uint8')
        tmpimg[:,:,0] = img[:]
        tmpimg[:,:,1] = img[:]
        tmpimg[:,:,2] = img[:]
        io.imsave(path+"0_"+str(i)+".jpg",tmpimg)