#这个文件用于统一剪切图片
import cv2
targetfilepath = "./data/train/"
for i in range(100):
    img = cv2.imread(targetfilepath+"0/0_"+str(i)+".jpg")#查一下怎么读取图片，全部切成等大的来训练
    img = img[:31,:31]
    cv2.imwrite(targetfilepath+"0/0_"+str(i)+".jpg",img)
targetfilepath = "./data/train/"
for i in range(100):
    img = cv2.imread(targetfilepath+"1/1_"+str(i)+".jpg")#查一下怎么读取图片，全部切成等大的来训练
    img = img[:31,:31]
    cv2.imwrite(targetfilepath+"1/1_"+str(i)+".jpg",img)
targetfilepath = "./data/test/"
for i in range(100):
    img = cv2.imread(targetfilepath+"0/0_"+str(i)+".jpg")#查一下怎么读取图片，全部切成等大的来训练
    img = img[:31,:31]
    cv2.imwrite(targetfilepath+"0/0_"+str(i)+".jpg",img)
targetfilepath = "./data/test/"
for i in range(100):
    img = cv2.imread(targetfilepath+"1/1_"+str(i)+".jpg")#查一下怎么读取图片，全部切成等大的来训练
    img = img[:31,:31]
    cv2.imwrite(targetfilepath+"1/1_"+str(i)+".jpg",img)
targetfilepath = "./data/val/"
for i in range(100):
    img = cv2.imread(targetfilepath+"0/0_"+str(i)+".jpg")#查一下怎么读取图片，全部切成等大的来训练
    img = img[:31,:31]
    cv2.imwrite(targetfilepath+"0/0_"+str(i)+".jpg",img)
targetfilepath = "./data/val/"
for i in range(100):
    img = cv2.imread(targetfilepath+"1/1_"+str(i)+".jpg")#查一下怎么读取图片，全部切成等大的来训练
    img = img[:31,:31]
    cv2.imwrite(targetfilepath+"1/1_"+str(i)+".jpg",img)
