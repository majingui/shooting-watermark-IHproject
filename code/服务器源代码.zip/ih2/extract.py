import math
import numpy
from hamming import *
from hamming_check import *
import torch
from skimage import io
import numpy as np
import torchvision
import cv2
from skimage import io
from skimage import transform
import matplotlib.pyplot as plt
import os
import torch
from torch.utils.data import Dataset,DataLoader
from torchvision.transforms import transforms
from model import *
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
myNET = torch.load('/root/ih2/modelsave/molnet2-alldata-200epoch-finetune.pth')#注意加载的model
myNET = myNET.to(device)
# img = io.imread("/root/ih2/outputimg/lenacoverrongyv.jpg") #嵌入的是01100101
#img = io.imread("/root/ih2/outputimg/bellcoverrongyv.jpg") #嵌入的是01100101
img = io.imread("/root/ih2/jiaozhengtestimg/belljiaozhengchange.jpg") #嵌入的是01100101
#img = io.imread("/root/ih2/outputimg/bellcover.jpg")#这个图嵌入的是全0
#img = io.imread("/root/ih2/outputimg/test.jpg")#没有嵌入就是看看，我发现一张图如果没有任何信息，模型倾向于识别为1
[m,n,c] = img.shape
msgcount = 0
M = math.floor(m/64)
N = math.floor(n/64)
msg = []
target = [0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1]
target0 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
target1 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
originmsg = [0,1,1,0,0,1,1,-1]
rongyv = [0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1,0,1,1,0,0,1,1,-1]
#已经证明这个处理过程没有问题，现在就看block能不能切出一张正常的图片了
# tmpimg = io.imread("/root/ih2/data/train/1/1_0.jpg")
# tmpimg = torch.from_numpy(tmpimg)
# tmpimg = tmpimg.float()
# tmpimg = tmpimg.reshape(1,64,64,3)
# tmpimg = tmpimg.permute(0,3,1,2)
# tmpimg = tmpimg.float()
# tmpimg = tmpimg.to(device)
# outputtmp = myNET(tmpimg)
# labeltmp = outputtmp.argmax(1)
time1 = time.time()
zhixindu = []
for i in range(M):
    if (msgcount == 64):
        break
    for j in range(N):
        if (msgcount == 64):
            break
        block = img[i*64:(i+1)*64,j*64:(j+1)*64,:] #注意python从0开始，左闭右开，matlab从1开始，闭区间
        #io.imsave("./tmp/"+str(i)+"_"+str(j)+".jpg",block)
        block = torch.from_numpy(block)
        block = block.float()
        #print(block.shape)
        block = block.reshape(1,64,64,3)
        #print(block.shape)
        block = block.permute(0,3,1,2)
        #print(block.shape)
        block = block.float()

        #cv2.imshow("tmp0",block.data.numpy())
        block = block.to(device)
        #key = cv2.waitKey(0)
        #cv2.imwrite("./tmp.jpg",block)
        output = myNET(block)
        label = output.argmax(1)
        output = output.cpu()
        output = output.detach()
        output = output.numpy()
        tmp = output[0][label[0]]
        zhixindu.append(tmp)
        #print(label)
        if(j==7):
            msg.append(-1)
        elif(label[0]==1):
            msg.append(1)
        else:
            msg.append(0)
        msgcount = msgcount+1

print("原始嵌入的信息（带纠错码）")
print(originmsg)
yes = 0
msglie= []
zhixindulie = []
for i in range(8):
    tmplie = []
    tmpposs = []
    for j in range(8):
        bit = msg[j*8+i]
        poss = zhixindu[j*8+i]
        tmplie.append(bit)
        tmpposs.append(poss)
    msglie.append(tmplie)
    zhixindulie.append(tmpposs)
result = []
resultposs = []
for i in range(8):
    vote = max(msglie[i],key=msglie[i].count)
    maxpossidx = zhixindulie[i].index(max(zhixindulie[i]))
    result.append(vote)
    resultposs.append(msglie[i][maxpossidx])

yes = 0
yesposs = 0
for i in range(len(originmsg)):
    if(originmsg[i]==result[i]):
        yes = yes + 1
    if (originmsg[i] == resultposs[i]):
        yesposs = yesposs + 1
print("vote方案下提取出的信息")
print(result)
print("准确率")
print(yes/len(originmsg))
print("poss方案下提取出的信息")
print(resultposs)
print("准确率")
print(yesposs/len(originmsg))
shortmsg = "0110"
print("hamming纠错中...")
result1 = ""
time2 = time.time()
print(time2-time1)
print("qqqqqqqqqqqqqqqqqqqq")
for i in range(7):
    result1 = result1 + str(resultposs[i])
time3 = time.time()
shortmsgnow = correct(result1)
time4 = time.time()
print("qqqqqqqqqqqqqqqqqqqq")
print(time4-time3)
print("最终提取的信息")
print(shortmsgnow)
yes = 0
for i in range(len(shortmsg)):
    if(shortmsg[i]==shortmsgnow[i]):
        yes = yes + 1
print("msg提取准确率BEAC")
print(yes/len(shortmsg))
print("比特错误率BER")
print(1-yes/len(shortmsg))
#因为更倾向于1，所以用投票的方式不太好只有50%，试试用概率的top1，3