import torch
from torch import nn

#创建神经网络
class myNET(nn.Module):
    def __init__(self):
        super(myNET, self).__init__()
        self.model = nn.Sequential(
            nn.Conv2d(3, 32, 5, 1, 2),#填充后刚好没有改变图片的大小，改变大小的只有池化，三次池化，从32*32到4*4
            nn.Conv2d(32, 32, 5, 1, 2),#molnet1新加了这一层
            nn.MaxPool2d(2),
            nn.Conv2d(32, 32, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 5, 1, 2),
            nn.MaxPool2d(2),
            nn.Flatten(),
            nn.Linear(4096, 256),
            nn.Linear(256,16),
            nn.Linear(16,2)
        )

    def forward(self, x):
        x = self.model(x)
        return x

if __name__=='__main__':
    myNET = myNET()
    input = torch.ones((64,3,32,32))#输入是四个维度，第一个维度是batch的大小，第二维是通道数，后面三四维是图片的大小
    output = myNET(input)#输入输出
    print(output.shape)#输出卷积后的大小，如果线性层不知道大小，可以通过这种方式，来获得扁平化后的大小或者图片的维度。
