import re
import time


def calcRedundantBits(m):
	for i in range(m):
		if(2**i >= m + i + 1):
			return i

def posRedundantBits(data, r):
	j = 0
	k = 1
	m = len(data)
	res = ''

	for i in range(1, m + r+1):
		if(i == 2**j):
			res = res + '0'
			j += 1
		else:
			res = res + data[-1 * k]
			k += 1

	return res[::-1]


def calcParityBits(arr, r):
	n = len(arr)

	for i in range(r):
		val = 0
		for j in range(1, n + 1):
			if(j & (2**i) == (2**i)):
				val = val ^ int(arr[-1 * j])
		arr = arr[:n-(2**i)] + str(val) + arr[n-(2**i)+1:]
	return arr


def detectError(arr, nr):
	n = len(arr)
	res = 0

	for i in range(nr):
		val = 0
		for j in range(1, n + 1):
			if(j & (2**i) == (2**i)):
				val = val ^ int(arr[-1 * j])

		res = res + val*(10**i)

	return int(str(res), 2)

#读入
'''
f = open('input.txt', 'r')
data = f.read()
f.close()
'''
def makehanming(msg):
	data_list = msg  # [0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1]
	data = re.sub("[^0-9]", "", data_list)
	#print("in:")
	#print(data)

	m = len(data)
	r = calcRedundantBits(m)
	arr = posRedundantBits(data, r)
	arr = calcParityBits(arr, r)

	# arr就是海明
	# 保存
	'''
	fh = open('output.txt', 'w', encoding='utf-8')
	fh.write(arr)
	fh.close()
	'''
	#print("out:")
	#print(len(arr))
	#print('[', end="")
	hanmingma = []
	for i in range(len(arr)):
		hanmingma.append(arr[i])
		#print(arr[i], end="")
		if i != len(arr) - 1:
			a = 0
			#print(',', end="")
	#print(']')
	return hanmingma
time1 = time.time()
han = makehanming("01100101")
han = makehanming("0110")
print(han)
time2 = time.time()
print(time2-time1)

#注意输入str输出list